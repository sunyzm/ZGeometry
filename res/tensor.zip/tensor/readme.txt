


This is a matlab demonstration code for the article:
A Tensor-Based Algorithm for High-Order Graph Matching,
published at ieee CVPR 2009,
by Olivier Duchenne, Francis Bach, Inso Kweon and Jean Ponce.

by Olivier Duchenne.

I. Introduction

This code generate a point cloud.
Then it creates a duplicate of this cloud rotate it, scale it, and add some noise.
Then the algorithm matches the two point clouds.

II. How to use

1/ lunch install.m
2/ lunch demo.m

III. Errors

As the code has been recentely completely rewritten for matlab bugs might remain.
If you find any error in this code, please email them to:
olivier.duchenne@ens.fr





